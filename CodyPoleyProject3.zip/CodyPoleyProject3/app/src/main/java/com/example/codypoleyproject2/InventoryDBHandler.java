package com.example.codypoleyproject2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class InventoryDBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1; //database version
    private static final String DATABASE_NAME = "inventory.db"; //database name
    private static final String TABLE_INVENTORY = "inventorys"; // table name

    private static final String KEY_ID = "id"; //inventory column id
    private static final String KEY_NAME = "name"; //inventory column name
    private static final String KEY_SKU = "SKU"; //inventory column SKU
    private static final String KEY_UNITS = "units"; //inventory column units
    private static final String KEY_LOCATION = "location"; //inventory column location

    public InventoryDBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        //create inventory table
        String CREATE_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
                + KEY_SKU + " TEXT," +KEY_UNITS + " TEXT," + KEY_LOCATION + " TEXT" + ")";
        db.execSQL(CREATE_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY); // if existed drop old inventory table
        onCreate(db);
    }



    // Adding new inventory
    void addInventory(Inventory inventory) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, inventory.getName()); // Inventory Name
        values.put(KEY_SKU, inventory.getSKU()); // Inventory SKU
        values.put(KEY_UNITS, inventory.getUnits()); // Inventory Units
        values.put(KEY_LOCATION, inventory.getLocation()); // Inventory Location



        db.insert(TABLE_INVENTORY, null, values);
        db.close(); // Closing database connection
    }

    // Getting single Inventory
    Inventory getInventory(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_INVENTORY, new String[] { KEY_ID,
                        KEY_NAME, KEY_SKU, KEY_UNITS, KEY_LOCATION }, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Inventory inventory = new Inventory(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));
        // return inventory
        return inventory;
    }

    // Getting All Inventory
    public List<Inventory> getAllInventory() {
        List<Inventory> inventoryList = new ArrayList<Inventory>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_INVENTORY;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Inventory inventory = new Inventory();
                inventory.setID(Integer.parseInt(cursor.getString(0)));
                inventory.setName(cursor.getString(1));
                inventory.setSku(cursor.getString(2));
                inventory.setUnits(cursor.getString(3));
                inventory.setLocation(cursor.getString(4));

                String name = cursor.getString(1) +"\n"
                        + cursor.getString(2) + "\n"
                        + cursor.getString(3) + "\n"
                        + cursor.getString(4);
                InventoryActivity.ArrayOfProduct.add(name);
                // Adding inventory to list
                inventoryList.add(inventory);
            } while (cursor.moveToNext());
        }

        // return inventory list
        return inventoryList;
    }

    // Updating single inventory
    public void updateInventory(Inventory inventory) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(KEY_NAME, inventory.getName());
        cv.put(KEY_SKU, inventory.getSKU());
        cv.put(KEY_UNITS, inventory.getUnits());
        cv.put(KEY_LOCATION, inventory.getLocation());

        // updating row
        db.update(TABLE_INVENTORY, cv, KEY_ID + " = ?",
                new String[] { String.valueOf(inventory.getID()) });
        db.close();
    }

    // Deleting single inventory
    public void deleteInventory(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INVENTORY, "name=?", new String[]{name});
        db.close();
    }





}
