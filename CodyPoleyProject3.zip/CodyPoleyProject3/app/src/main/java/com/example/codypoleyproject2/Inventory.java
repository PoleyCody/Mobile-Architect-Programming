package com.example.codypoleyproject2;

public class Inventory {


    //private variables
    private int id;
    private String name;
    private String sku;
    private String units;
    private  String location;

    // Empty constructor
    public Inventory(){

    }
    // constructor with all variables
    public Inventory(int id, String name, String sku, String units, String location){
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.units = units;
        this.location = location;
    }
    //constructer without id
    public Inventory(String name , String sku, String units, String location) {
        this.name = name;
        this.sku = sku;
        this.units = units;
        this.location = location;
    }



    // get id
    public int getID(){
        return this.id;
    }

    // set id
    public void setID(int id){
        this.id = id;
    }

    // get name
    public String getName(){
        return this.name;
    }

    // set name
    public void setName(String name){
        this.name = name;
    }

    // get SKU
    public String getSKU(){
        return this.sku;
    }

    // set SKU
    public void setSku(String sku){
        this.sku = sku;
    }

    // get units
    public String getUnits(){
        return this.units;
    }

    // set units
    public void setUnits(String units){
        this.sku = units;
    }

    // get location
    public String getLocation(){
        return this.location;
    }

    // set location
    public void setLocation(String location){
        this.sku = location;
    }

}
