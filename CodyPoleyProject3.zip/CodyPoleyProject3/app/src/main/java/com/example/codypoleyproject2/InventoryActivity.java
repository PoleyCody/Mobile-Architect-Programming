package com.example.codypoleyproject2;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    // set variables
    private GridView gridView;
    private EditText nameText;
    private EditText skuText;
    private EditText unitText;
    private EditText locationText;
    public Button addButton;
    public Button deleteButton;
    public Button updateButton;
    public static ArrayList<String> ArrayOfProduct = new ArrayList<>();
    public static ArrayAdapter<String> adapter;
    InventoryDBHandler handler;


    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        gridView = (GridView) findViewById(R.id.gridView);
        nameText = (EditText) findViewById(R.id.productEditText);
        skuText = (EditText) findViewById(R.id.skuEditText);
        unitText = (EditText) findViewById(R.id.unitEditText);
        locationText = (EditText) findViewById(R.id.locationEditText);
        addButton = (Button) findViewById(R.id.addButton);
        deleteButton = (Button) findViewById(R.id.deleteButton);
        updateButton = (Button) findViewById(R.id.updateButton);
        InventoryDBHandler db = new InventoryDBHandler(this);

        //add button event
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameText.getText().toString(); //get product name from Edittext
                String skuTxt = skuText.getText().toString(); //get SKU from Edittext
                String unit = unitText.getText().toString(); //get units from Edittext
                String location = locationText.getText().toString(); //get location from Edittext

                if(!name.equals("")) {
                    db.addInventory(new Inventory(name, skuTxt, unit, location)); //add values to database
                    fillInventory();
                }else {
                    Toast.makeText(InventoryActivity.this, "Product Name can not be empty", Toast.LENGTH_SHORT).show();
                }
            }
        });



        //delete button event
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String productName = nameText.getText().toString(); //get product name from Edittext
                db.deleteInventory(productName); //delete from database
            }
        });

        //update button event
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String productName = nameText.getText().toString(); //get product name from Edittext
                String productSKU = skuText.getText().toString(); //get SKU from Edittext
                String productUnits = unitText.getText().toString(); //get units from Edittext
                String productLocation = locationText.getText().toString(); //get location from Edittext
                Inventory inventory = new Inventory(productName, productSKU, productUnits, productLocation); //set inventory with all variables
                db.updateInventory(inventory); //update database
                fillInventory();
            }
        });

        // Reading all inventories
        List<Inventory> inventories = db.getAllInventory();

        db.getAllInventory(); //get all items in the database

        GridView gridView = (GridView) findViewById(R.id.gridView); //set gridView

        //set adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, ArrayOfProduct);

        gridView.setAdapter(adapter);

        //grid event
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Toast.makeText(getApplicationContext(),
                        ((TextView) v).getText(), Toast.LENGTH_SHORT).show(); //populate grid
            }
        });
    }

    public void fillInventory() {
        try {
            int[] id = {R.id.txtListElement};
            String[] inventoryName = new String[]{"InventoryName"};
            if (handler == null) {
                handler = new InventoryDBHandler(this);
            }
            SQLiteDatabase db = handler.getReadableDatabase();
            Cursor c = (Cursor) handler.getAllInventory();

            SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                    R.layout.inventory_list, c, inventoryName, id, 0);
            gridView.setAdapter(adapter);

        } catch (Exception ex) {
            Toast.makeText(InventoryActivity.this, ex.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }


}