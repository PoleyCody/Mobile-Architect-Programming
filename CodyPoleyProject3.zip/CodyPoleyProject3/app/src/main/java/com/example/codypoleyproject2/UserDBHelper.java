package com.example.codypoleyproject2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class UserDBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "Login.db"; //name of database

    public UserDBHelper(Context context) {
        super(context, "Login.db", null, 1);
    } //set UserDBHelper

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table users(username TEXT primary key, password TEXT)"); //set username and password in database
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists users");
    }

    //add account to database
    public Boolean insertAccount(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase(); //set db
        ContentValues cv = new ContentValues(); //set cv
        cv.put("username", username); //add username to cv
        cv.put("password", password); //add password to cv
        long result = db.insert("users", null, cv); //add username and password to db
        if(result == -1) { //if db.insert does not add account
            return false;
        }else {
            return true;
        }
    }

    //check username method
    public Boolean checkUsername(String username) {
        SQLiteDatabase db = this.getWritableDatabase(); //set db
        Cursor cursor = db.rawQuery("Select * from users where username = ?", new String[] {username}); //look for username in db
        if(cursor.getCount() > 0) { //if cursor empty
            return true;
        }else {
            return false;
        }
    }

    //check both username and password
    public Boolean checkUsernameAndPassword(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase(); //set db
        Cursor cursor = db.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password}); //look for username and password in db
        if(cursor.getCount() > 0) { //if cursor empty
            return true;
        }else {
            return false;
        }
    }
}
