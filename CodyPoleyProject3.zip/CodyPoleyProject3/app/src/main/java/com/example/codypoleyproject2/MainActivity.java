package com.example.codypoleyproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username, password; //create EditText variables
    Button login, createAccount; //create Button variables
    UserDBHelper db; //create UserDBHelper variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.usernameText); //set username to usernameText
        password = (EditText) findViewById(R.id.passwordText); //set password to passwordText
        login = (Button) findViewById(R.id.loginButton); //set login to loginButton
        createAccount = (Button) findViewById(R.id.accountButton); //set createAccount to accountButton
        db = new UserDBHelper(this); //set db to UserDBHelper

        //createAccount button event
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString(); //get username from EditText
                String pass = password.getText().toString(); //get password from EditText

                if (user.equals("") && pass.equals("")) { //if username and password empty
                    Toast.makeText(MainActivity.this, "Enter both username and password", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUser = db.checkUsername(user); //check username is in database
                    if (!checkUser) { //if not in database
                        Boolean insert = db.insertAccount(user, pass); //add username and password to database
                        if (insert) { //if username and password where added to database
                            Toast.makeText(MainActivity.this, "Account Add", Toast.LENGTH_SHORT).show(); //let the user know the account was add to database
                            Intent intent = new Intent(getApplicationContext(), messageActivity.class); //set intent to InventoryActivity
                            startActivity(intent); //run InventoryActivity
                        } else {
                            Toast.makeText(MainActivity.this, "Error failure to Create Account.", Toast.LENGTH_SHORT).show(); //let user know their account was not created
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Username Already in System", Toast.LENGTH_SHORT).show(); //let user know the username is already in the database
                    }
                }
            }
        });
        //login button event
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString(); //get username from EditText
                String pass = password.getText().toString(); //get password from EditText

                if ((user.equals("") && pass.equals("")) || (user.equals("") || pass.equals(""))) { //if both username and password are empty or one of them is
                    Toast.makeText(MainActivity.this, "Enter Username and Password", Toast.LENGTH_SHORT).show(); //tell user they need to fill out both
                } else {
                    Boolean checkUserPass = db.checkUsernameAndPassword(user, pass); //check username and password
                    if (checkUserPass) { //if username and password are correct
                        Intent intent = new Intent(getApplicationContext(), messageActivity.class); //set intent to InventoryActivity
                        startActivity(intent); //run InventoryActivity
                    } else {
                        Toast.makeText(MainActivity.this, "Error Wrong Username and Password", Toast.LENGTH_SHORT).show(); //let user know they entered the wrong username or password
                    }
                }
            }
        });
    }

}